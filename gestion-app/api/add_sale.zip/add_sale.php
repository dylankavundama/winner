<?php
session_start();

// Ensure user is logged in
 

// Include database connection
// Assuming db.php establishes a PDO connection named $pdo
require_once '../config/db.php'; 

// --- Start: API Logic for Product Search (GET Request) ---
// This part handles the product search initiated by Flutter's TypeAhead
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['ajax_search']) && $_GET['ajax_search'] === 'true') {
    $search_query = trim($_GET['query'] ?? ''); // Trim whitespace from query
    $products = [];
    try {
        if (!empty($search_query)) { // Only search if query is not empty
            // Search by product name, limit to 50 results
            $stmt = $pdo->prepare('SELECT id, name, prix_vente, quantity FROM products WHERE name LIKE ? LIMIT 50');
            $stmt->execute(['%' . $search_query . '%']);
            $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
        } 
        // If search_query is empty, $products will remain an empty array, which is suitable for TypeAhead.

        header('Content-Type: application/json');
        echo json_encode(['success' => true, 'products' => $products]);
        exit; // Important: Stop script execution after sending JSON
    } catch (PDOException $e) {
        // Log the error for debugging purposes (recommended in production)
        error_log('Database error during product search: ' . $e->getMessage()); 
        header('Content-Type: application/json');
        http_response_code(500); // Internal Server Error
        echo json_encode(['success' => false, 'message' => 'Database error during product search.']); // Generic message for client
        exit; // Important: Stop script execution
    }
}
// --- End: API Logic for Product Search ---


// --- Start: API Logic for Sale Submission (POST Request) ---
// This part handles the sale submission from Flutter
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Sanitize and validate input
    $client_id = filter_var($_POST['client_id'] ?? null, FILTER_VALIDATE_INT); // Use filter_var for client_id
    $user_id = $_SESSION['user_id']; // user_id is guaranteed to be set by the initial check
    
    // Ensure product_id, quantity, and new_price are arrays, even if empty
    $product_ids = $_POST['product_id'] ?? []; 
    $quantities = $_POST['quantity'] ?? []; 
    $new_prices = $_POST['new_price'] ?? []; 

    $imei = trim($_POST['imei'] ?? '');
    $garanti = trim($_POST['garanti'] ?? '');

    $total = 0;
    $valid = true;
    $vente = []; // Array to hold validated sale items
    $api_message = ''; // Message specifically for API response

    // 1. Initial Validation
    if ($client_id === false || $client_id <= 0) { // Check if client_id is a valid positive integer
        $api_message = 'Veuillez sélectionner un client valide.';
        $valid = false;
    } elseif (empty($product_ids)) {
        $api_message = 'Veuillez ajouter au moins un produit à la vente.';
        $valid = false;
    } elseif (empty($imei)) {
        $api_message = 'L\'adresse IMEI est requise.';
        $valid = false;
    }

    // 2. Re-fetch product data for server-side validation
    $current_products_in_db = [];
    if ($valid && !empty($product_ids)) {
        // Ensure product_ids are integers for the IN clause
        $clean_product_ids = array_filter(array_map('intval', $product_ids), function($id) { return $id > 0; });
        
        if (empty($clean_product_ids)) {
            $api_message = 'Aucun produit valide sélectionné.';
            $valid = false;
        } else {
            $placeholders = implode(',', array_fill(0, count($clean_product_ids), '?'));
            try {
                $stmt = $pdo->prepare("SELECT id, name, prix_vente, quantity FROM products WHERE id IN ($placeholders)");
                $stmt->execute($clean_product_ids);
                foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $p) {
                    $current_products_in_db[$p['id']] = $p;
                }
                // Verify if all submitted product_ids actually exist in the database
                if (count($current_products_in_db) !== count($clean_product_ids)) {
                    $api_message = 'Un ou plusieurs produits sélectionnés n\'existent plus ou ont été retirés.';
                    $valid = false;
                }
            } catch (PDOException $e) {
                error_log('Database error during product validation: ' . $e->getMessage());
                $api_message = 'Erreur de base de données lors de la validation des produits.';
                $valid = false;
            }
        }
    }

    // 3. Detailed Product Validation and Total Calculation
    if ($valid) {
        foreach ($product_ids as $pid_str) {
            $pid = intval($pid_str); // Ensure product ID is an integer
            
            // Skip if PID is invalid or not found in DB fetch (due to potential malicious input or race condition)
            if ($pid <= 0 || !isset($current_products_in_db[$pid])) {
                $valid = false;
                $api_message = 'Un produit sélectionné est invalide ou n\'existe plus: ID ' . $pid_str;
                break;
            }

            $qte = (int)($quantities[$pid_str] ?? 0); // Quantity comes from array keyed by product ID string
            $submitted_price = trim($new_prices[$pid_str] ?? ''); // Price comes from array keyed by product ID string

            $db_product = $current_products_in_db[$pid];

            // Determine the applied price (override or default)
            $applied_price = (!empty($submitted_price) && is_numeric($submitted_price)) ? floatval($submitted_price) : floatval($db_product['prix_vente']);
            
            // Basic price validation: ensure it's not negative
            if ($applied_price < 0) {
                $valid = false;
                $api_message = 'Le prix de vente ne peut pas être négatif pour le produit ' . $db_product['name'] . '.';
                break;
            }

            // Validate quantity
            if ($qte <= 0) {
                $valid = false;
                $api_message = 'Veuillez entrer une quantité valide (> 0) pour le produit ' . $db_product['name'] . '.';
                break;
            }

            // Validate stock
            if ($qte > $db_product['quantity']) {
                $valid = false; // Set valid to false directly as this is a critical error
                $api_message = 'Stock insuffisant pour le produit ' . $db_product['name'] . '. Stock disponible: ' . $db_product['quantity'] . ', Quantité demandée: ' . $qte;
                break;
            }

            $total += $applied_price * $qte;
            $vente[] = [
                'id' => $pid,
                'qte' => $qte,
                'price' => $applied_price
            ];
        }
    }

    // 4. Execute Transaction if Valid
    if ($valid) {
        try {
            $pdo->beginTransaction();

            // Insert into sales table
            $stmt = $pdo->prepare('INSERT INTO sales (client_id, user_id, total, imei, garanti, sale_date) VALUES (?, ?, ?, ?, ?, NOW())');
            $stmt->execute([$client_id, $user_id, $total, $imei, $garanti]);
            $sale_id = $pdo->lastInsertId();

            // Insert into sale_details and update product stock
            $stmt_detail = $pdo->prepare('INSERT INTO sale_details (sale_id, product_id, quantity, price) VALUES (?, ?, ?, ?)');
            $stmt_update_stock = $pdo->prepare('UPDATE products SET quantity = quantity - ? WHERE id = ?');

            foreach ($vente as $v) {
                $stmt_detail->execute([$sale_id, $v['id'], $v['qte'], $v['price']]);
                $stmt_update_stock->execute([$v['qte'], $v['id']]);
            }

            $pdo->commit();
            header('Content-Type: application/json');
            echo json_encode(['success' => true, 'message' => 'Vente enregistrée avec succès!', 'sale_id' => $sale_id]);
            exit; // Important: Stop script execution after success
        } catch (PDOException $e) {
            $pdo->rollBack();
            error_log('Error saving sale transaction: ' . $e->getMessage());
            $api_message = 'Erreur lors de l\'enregistrement de la vente.'; // Generic message for client
        }
    }

    // If we reach here, it means there was a validation error or database error
    header('Content-Type: application/json');
    http_response_code(400); // Use 400 Bad Request for validation errors
    echo json_encode(['success' => false, 'message' => $api_message]);
    exit; // Important: Stop script execution after error
}

// If neither GET (ajax_search) nor POST request is detected, this script does nothing
// and will effectively return an empty response or a 404 if accessed directly without parameters.
?>