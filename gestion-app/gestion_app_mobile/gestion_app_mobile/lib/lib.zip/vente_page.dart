import 'dart:async';

import 'package:flutter/material.dart';
import 'package:gestion_app_mobile/client_model.dart';
import 'package:gestion_app_mobile/constants.dart';
import 'package:gestion_app_mobile/product_model.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:intl/intl.dart';
import 'package:gestion_app_mobile/facture_page.dart';

class VentePage extends StatefulWidget {
  const VentePage({Key? key}) : super(key: key);

  @override
  State<VentePage> createState() => _VentePageState();
}

class _VentePageState extends State<VentePage> {
  final PageController _pageController = PageController();
  int _currentPage = 0;
  bool _isLoading = false;
  String? _errorMessage;

  // Contrôleurs de formulaire
  final TextEditingController _clientNameController = TextEditingController();
  final TextEditingController _clientAddressController = TextEditingController();
  final TextEditingController _garantieController = TextEditingController();
  final TextEditingController _imeiController = TextEditingController();
  final TextEditingController _productSearchController = TextEditingController();

  // Données
  List<SaleProduct> _selectedProducts = [];
  List<Product> _allProducts = [];
  List<Product> _filteredProducts = [];
  List<Client> _clients = [];
  Client? _selectedClient;
  bool _showProductDropdown = false;

  final NumberFormat _currencyFormatter = NumberFormat.currency(
    locale: 'fr_FR',
    symbol: '€',
    decimalDigits: 2,
  );

  @override
  void initState() {
    super.initState();
    _loadInitialData();
  }

  @override
  void dispose() {
    _clientNameController.dispose();
    _clientAddressController.dispose();
    _garantieController.dispose();
    _imeiController.dispose();
    _productSearchController.dispose();
    _pageController.dispose();
    super.dispose();
  }

  Future<void> _loadInitialData() async {
    setState(() => _isLoading = true);
    try {
      await Future.wait([
        _fetchClients(),
        _fetchAllProducts(),
      ]);
    } catch (e) {
      setState(() => _errorMessage = 'Erreur de chargement: ${e.toString()}');
    } finally {
      setState(() => _isLoading = false);
    }
  }

  Future<void> _fetchClients() async {
    try {
      final response = await http.get(Uri.parse(ApiConstants.clientsApi));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body) as Map<String, dynamic>;
        if (data['success'] == true) {
          setState(() {
            _clients = (data['clients'] as List)
                .map((json) => Client.fromJson(json))
                .toList();
          });
        } else {
          print('API returned success: false. Message: ${data['message']}');
        }
      } else {
        print('HTTP Request Failed with Status Code: ${response.statusCode}');
      }
    } catch (e) {
      print('Error fetching clients: $e');
    }
  }

  Future<void> _fetchAllProducts() async {
    try {
      final response = await http.get(Uri.parse(ApiConstants.productsApi));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body) as Map<String, dynamic>;
        if (data['success'] == true) {
          setState(() {
            _allProducts = (data['products'] as List)
                .map((json) => Product.fromJson(json))
                .toList();
          });
        } else {
          setState(() {
            _errorMessage = data['message'] ?? 'Erreur lors du chargement des produits';
          });
        }
      } else {
        setState(() {
          _errorMessage = 'Erreur serveur (${response.statusCode})';
        });
      }
    } catch (e) {
      setState(() {
        _errorMessage = 'Erreur de connexion: ${e.toString()}';
      });
    }
  }

  // Méthode pour filtrer les produits
  void _filterProducts(String query) {
    setState(() {
      if (query.isEmpty) {
        _filteredProducts = [];
        _showProductDropdown = false;
      } else {
        _filteredProducts = _allProducts.where((product) {
          return product.name.toLowerCase().contains(query.toLowerCase()) ||
                 product.id.toString().contains(query);
        }).toList();
        _showProductDropdown = _filteredProducts.isNotEmpty;
      }
    });
  }

  void _nextPage() {
    if (_pageController.page!.toInt() < 3) {
      _pageController.nextPage(
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeInOut,
      );
    }
  }

  void _previousPage() {
    if (_pageController.page!.toInt() > 0) {
      _pageController.previousPage(
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeInOut,
      );
    }
  }

  Future<int?> _addNewClient(String name) async {
    try {
      final response = await http.post(
        Uri.parse(ApiConstants.clientsApi),
        headers: {'Content-Type': 'application/json'},
        body: json.encode({'name': name}),
      );
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['success'] == true && data['client_id'] != null) {
          return data['client_id'] as int;
        }
      }
      return null;
    } catch (e) {
      return null;
    }
  }

  Future<void> _handleNextClientStep() async {
    final newClientName = _clientNameController.text.trim();
    
    // Priorité: nouveau client si saisi
    if (newClientName.isNotEmpty) {
      final clientId = await _addNewClient(newClientName);
      if (clientId != null) {
        final newClient = Client(id: clientId, name: newClientName);
        setState(() {
          _clients.add(newClient);
          _selectedClient = newClient;
        });
        _clientNameController.clear();
        _nextPage();
      } else {
        _showError('Erreur lors de la création du client');
      }
    } 
    // Sinon, vérifier qu'un client existant est sélectionné
    else if (_selectedClient != null) {
      _nextPage();
    } 
    // Aucun client sélectionné
    else {
      _showError('Veuillez sélectionner ou créer un client');
    }
  }

  // Méthode améliorée pour ajouter un produit (avec validation)
  void _addProduct(Product product) {
    // Vérifier si le produit est déjà ajouté
    final isAlreadyAdded = _selectedProducts.any((p) => p.id == product.id);
    if (isAlreadyAdded) {
      _showError('Ce produit est déjà dans la liste');
      return;
    }
    
    // Vérifier le stock
    if (product.quantity <= 0) {
      _showError('Stock insuffisant pour ${product.name}');
      return;
    }
    
    setState(() {
      _selectedProducts.add(SaleProduct(
        id: product.id,
        name: product.name,
        prixVente: product.prixVente,
        quantity: product.quantity,
        quantityToSell: 1,
        priceOverride: product.prixVente,
      ));
    });
    
    _showSuccess('${product.name} ajouté à la vente');
  }

  Future<void> _submitSale() async {
    if (_selectedClient == null) {
      _showError('Veuillez sélectionner un client');
      _pageController.jumpToPage(0);
      return;
    }

    if (_selectedProducts.isEmpty) {
      _showError('Veuillez sélectionner au moins un produit');
      return;
    }

    setState(() => _isLoading = true);

    try {
      final prefs = await SharedPreferences.getInstance();
      final userId = prefs.getInt('user_id') ?? 1; // Default to 1 if not set

      final response = await http
          .post(
            Uri.parse(ApiConstants.addSaleApi),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({
              'client_id': _selectedClient!.id,
              'user_id': userId,
              'total': _calculateTotal(),
              'imei': _imeiController.text,
              'garanti': _garantieController.text,
              'products': _selectedProducts
                  .map((p) => {
                        'id': p.id,
                        'quantity': p.quantityToSell,
                        'price': p.priceOverride,
                      })
                  .toList(),
            }),
          )
          .timeout(const Duration(seconds: 30));

      print('Response status: ${response.statusCode}');
      print('Response body: ${response.body}');

      if (response.statusCode == 200) {
        try {
          final responseData = jsonDecode(response.body);
          
          if (responseData['success'] == true) {
            _showSuccess(responseData['message'] ?? '');
            try {
              final saleId = int.tryParse(responseData['sale_id'].toString()) ?? 0;
              // Générer la facture automatiquement
              final invoiceId = await _generateInvoice(saleId);
              if (invoiceId != null) {
                // ignore: use_build_context_synchronously
                await showDialog(
                  context: context,
                  barrierDismissible: false,
                  builder: (context) {
                    return AlertDialog(
                      title: const Text('Vente enregistrée avec succès'),
                      content: Column(
                        mainAxisSize: MainAxisSize.min,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('Client : ${_selectedClient?.name ?? ''}'),
                          Text('Total : ${_calculateTotal().toStringAsFixed(2)}'),
                          Text('Date : ${DateFormat('yyyy-MM-dd HH:mm').format(DateTime.now())}'),
                          if (_imeiController.text.isNotEmpty) Text('IMEI : ${_imeiController.text}'),
                          if (_garantieController.text.isNotEmpty) Text('Garantie : ${_garantieController.text}'),
                        ],
                      ),
                      actions: [
                        TextButton(
                          onPressed: () => Navigator.of(context).pop(),
                          child: const Text('Fermer'),
                        ),
                        ElevatedButton.icon(
                          icon: const Icon(Icons.print),
                          label: const Text('Imprimer la facture'),
                          onPressed: () {
                            Navigator.of(context).pop();
                            Navigator.of(context).push(
                              MaterialPageRoute(
                                builder: (context) => FacturePage(invoiceId: invoiceId),
                              ),
                            );
                          },
                        ),
                      ],
                    );
                  },
                );
              } else {
                _showError('Erreur lors de la génération de la facture');
              }
            } catch (e) {
              print('Erreur lors de la création de la facture: $e');
              Navigator.of(context).pop();
            }
          } else {
            _showError(responseData['message'] ?? 'Erreur lors de la vente');
          }
        } on FormatException catch (e) {
          print('JSON parsing error: $e');
          print('Response body: ${response.body}');
          _showError('Erreur de format de réponse du serveur');
        }
      } else {
        _showError('Erreur serveur (${response.statusCode}): ${response.body}');
      }
    } on TimeoutException {
      _showError('Timeout: Le serveur ne répond pas');
    } catch (e) {
      print('Error in _submitSale: $e');
      _showError('Erreur: ${e.toString()}');
    } finally {
      setState(() => _isLoading = false);
    }
  }

  double _calculateTotal() {
    return _selectedProducts.fold(
        0.0,
        (sum, product) =>
            sum + (product.priceOverride * product.quantityToSell));
  }

  void _showError(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), backgroundColor: Colors.red),
    );
  }

  void _showSuccess(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), backgroundColor: Colors.green),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Nouvelle Vente'),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : Column(
              children: [
                LinearProgressIndicator(value: (_currentPage + 1) / 4),
                Expanded(
                  child: PageView(
                    controller: _pageController,
                    onPageChanged: (index) =>
                        setState(() => _currentPage = index),
                    physics: const NeverScrollableScrollPhysics(),
                    children: [
                      _buildClientInfoPage(),
                      _buildAddressPage(),
                      _buildWarrantyPage(),
                      _buildProductSelectionPage(),
                    ],
                  ),
                ),
                _buildNavigationButtons(),
              ],
            ),
    );
  }

  Widget _buildClientInfoPage() {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Informations Client',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const SizedBox(height: 24),
          DropdownButtonFormField<Client>(
            isExpanded: true,
            decoration: const InputDecoration(
              labelText: 'Client existant',
              border: OutlineInputBorder(),
            ),
            value: _selectedClient,
            items: _clients
                .map((client) => DropdownMenuItem(
                      value: client,
                      child: Text(client.name),
                    ))
                .toList(),
            onChanged: (client) => setState(() => _selectedClient = client),
            hint: const Text('Sélectionnez un client'),
          ),
          const SizedBox(height: 16),
          const Text('OU', 
              textAlign: TextAlign.center,
              style: TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 16),
          TextFormField(
            controller: _clientNameController,
            decoration: const InputDecoration(
              labelText: 'Nouveau client*',
              border: OutlineInputBorder(),
              hintText: 'Nom du nouveau client',
            ),
            validator: (value) =>
                value?.isEmpty ?? true ? 'Ce champ est obligatoire' : null,
          ),
          const SizedBox(height: 16),
          const Text('* Champs obligatoires',
              style: TextStyle(fontSize: 12, color: Colors.grey)),
        ],
      ),
    );
  }

  Widget _buildAddressPage() {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Adresse Client',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const SizedBox(height: 24),
          TextFormField(
            controller: _clientAddressController,
            decoration: const InputDecoration(
              labelText: 'Adresse',
              border: OutlineInputBorder(),
              hintText: 'Optionnel',
            ),
          ),
          const SizedBox(height: 24),
          TextFormField(
            controller: _imeiController,
            decoration: const InputDecoration(
              labelText: 'IMEI',
              border: OutlineInputBorder(),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildWarrantyPage() {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Garantie',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const SizedBox(height: 24),
          TextFormField(
            controller: _garantieController,
            decoration: const InputDecoration(
              labelText: 'Durée de garantie',
              border: OutlineInputBorder(),
              hintText: 'Ex: 6 mois, 1 an...',
            ),
          ),
        ],
      ),
    );
  }

  // Widget de recherche de produits
  Widget _buildProductSearchWidget() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        TextFormField(
          controller: _productSearchController,
          decoration: const InputDecoration(
            labelText: 'Rechercher un produit',
            hintText: 'Tapez le nom du produit...',
            border: OutlineInputBorder(),
            prefixIcon: Icon(Icons.search),
          ),
          onChanged: _filterProducts,
          onTap: () {
            if (_productSearchController.text.isNotEmpty) {
              _filterProducts(_productSearchController.text);
            }
          },
        ),
        if (_showProductDropdown) ...[
          const SizedBox(height: 8),
          Container(
            constraints: const BoxConstraints(maxHeight: 200),
            decoration: BoxDecoration(
              border: Border.all(color: Colors.grey.shade300),
              borderRadius: BorderRadius.circular(4),
            ),
            child: ListView.builder(
              shrinkWrap: true,
              itemCount: _filteredProducts.length,
              itemBuilder: (context, index) {
                final product = _filteredProducts[index];
                final isAlreadyAdded = _selectedProducts.any((p) => p.id == product.id);
                
                return ListTile(
                  title: Text(product.name),
                  subtitle: Text('Stock: ${product.quantity} - Prix: ${product.prixVente.toStringAsFixed(2)}€'),
                  trailing: isAlreadyAdded 
                    ? const Icon(Icons.check, color: Colors.green)
                    : product.quantity > 0 
                      ? const Icon(Icons.add_circle_outline, color: Colors.blue)
                      : const Icon(Icons.block, color: Colors.red),
                  enabled: !isAlreadyAdded && product.quantity > 0,
                  onTap: isAlreadyAdded || product.quantity <= 0 ? null : () {
                    _addProduct(product);
                    _productSearchController.clear();
                    _filterProducts('');
                  },
                );
              },
            ),
          ),
        ],
      ],
    );
  }

  Widget _buildProductSelectionPage() {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Produits à Vendre',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const SizedBox(height: 16),
          
          // Widget de recherche de produits - FIXE dans un container
          SizedBox(
            height: _showProductDropdown ? 280 : 80, // Hauteur fixe
            child: _buildProductSearchWidget(),
          ),
          
          const SizedBox(height: 16),
          
          // Zone des produits sélectionnés - utilise l'espace restant
          Expanded(
            child: _selectedProducts.isNotEmpty 
              ? Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text('Produits sélectionnés:',
                            style: TextStyle(fontWeight: FontWeight.bold)),
                        Text('(${_selectedProducts.length} produit${_selectedProducts.length > 1 ? 's' : ''})',
                            style: TextStyle(color: Colors.grey[600])),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Expanded(
                      child: ListView.builder(
                        itemCount: _selectedProducts.length,
                        itemBuilder: (context, index) {
                          final product = _selectedProducts[index];
                          return Card(
                            margin: const EdgeInsets.symmetric(vertical: 4),
                            child: ListTile(
                              title: Text(product.name),
                              subtitle: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text('Prix: ${_currencyFormatter.format(product.priceOverride)}'),
                                  Row(
                                    children: [
                                      const Text('Quantité: '),
                                      IconButton(
                                        icon: const Icon(Icons.remove_circle_outline),
                                        onPressed: () => _updateProductQuantity(
                                            product.id, product.quantityToSell - 1),
                                      ),
                                      Container(
                                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                                        decoration: BoxDecoration(
                                          border: Border.all(color: Colors.grey),
                                          borderRadius: BorderRadius.circular(4),
                                        ),
                                        child: Text('${product.quantityToSell}'),
                                      ),
                                      IconButton(
                                        icon: const Icon(Icons.add_circle_outline),
                                        onPressed: () => _updateProductQuantity(
                                            product.id, product.quantityToSell + 1),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                              trailing: IconButton(
                                icon: const Icon(Icons.delete, color: Colors.red),
                                onPressed: () => _removeProduct(product.id),
                                tooltip: 'Supprimer ce produit',
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: Colors.grey[100],
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text('Total:', 
                              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                          Text(_currencyFormatter.format(_calculateTotal()),
                              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.green)),
                        ],
                      ),
                    ),
                  ],
                )
              : Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.shopping_cart_outlined, size: 64, color: Colors.grey[400]),
                      const SizedBox(height: 16),
                      Text('Aucun produit sélectionné', 
                           style: TextStyle(fontSize: 16, color: Colors.grey[600])),
                      const SizedBox(height: 8),
                      Text('Utilisez la barre de recherche pour ajouter des produits',
                           style: TextStyle(color: Colors.grey[500])),
                    ],
                  ),
                ),
          ),
        ],
      ),
    );
  }

  Widget _buildNavigationButtons() {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          if (_currentPage > 0)
            ElevatedButton(
              onPressed: _previousPage,
              child: const Text('Précédent'),
            ),
          if (_currentPage < 3)
            ElevatedButton(
              onPressed: () {
                if (_currentPage == 0) {
                  _handleNextClientStep();
                } else {
                  _nextPage();
                }
              },
              child: const Text('Suivant'),
            ),
          if (_currentPage == 3)
            ElevatedButton(
              onPressed: _isLoading ? null : _submitSale,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.green,
              ),
              child: _isLoading 
                ? const SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2),
                  )
                : const Text('Terminer'),
            ),
        ],
      ),
    );
  }

  void _updateProductQuantity(int productId, int newQuantity) {
    setState(() {
      final product = _selectedProducts.firstWhere((p) => p.id == productId);
      if (newQuantity > 0 && newQuantity <= product.quantity) {
        product.quantityToSell = newQuantity;
      } else if (newQuantity == 0) {
        _selectedProducts.removeWhere((p) => p.id == productId);
      }
    });
  }

  void _removeProduct(int productId) {
    setState(() {
      _selectedProducts.removeWhere((p) => p.id == productId);
    });
  }

  // Ajoute cette méthode pour générer la facture via l'API
  Future<int?> _generateInvoice(int saleId) async {
    try {
      final response = await http.post(
        Uri.parse('${ApiConstants.baseUrl}/add_invoice.php'),
        headers: {'Content-Type': 'application/json'},
        body: json.encode({'sale_id': saleId}),
      );
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['success'] == true && data['invoice_id'] != null) {
          return data['invoice_id'] as int;
        }
      }
      return null;
    } catch (e) {
      return null;
    }
  }
}